class Constants {
  Constants._();

  static const appName = 'WorkForce';

  // SVG Icons
  static const svgPath = 'images/svg';
  static const imgPath = 'images/img';

  // ---------------------------------------------
}
