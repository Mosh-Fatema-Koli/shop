import 'dart:developer';

void kLog(value) {
  log('$value');
}
